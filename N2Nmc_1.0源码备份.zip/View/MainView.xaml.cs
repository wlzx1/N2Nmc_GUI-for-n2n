﻿using n2nmc.View.Pagey;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Net;
using log4net;

namespace n2nmc.View
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    
    public partial class MainView : Window
    {
        //全局n2n服务器ip
        public static string severip = "14.29.239.175:7777";
        public static string severapi = "14.29.239.175:58888";
        //用于page2窗口控件状态
        public static int pass;
        public static int guanbipage2;
        public static string jiedian = "";

        public MainView()
        {
            InitializeComponent();
            tap();
            log4net.Config.XmlConfigurator.Configure();
            
        }
        
        private static void ChageEvent() {

            
        }
        //public static void tiaozhuanpage5() {
        //    //MainView.



        public void logm(string loga) {
            ILog log = log4net.LogManager.GetLogger(typeof(MainView));
            log.Info(loga);
        }


        //}
        //左侧边栏按钮
        public void tiaozhuan(string ye) {
            Framez.Source = new Uri("Pagey/"+ye+".xaml", UriKind.Relative);
            
        }

        private void Page1Button_Click(object sender, RoutedEventArgs e)
        {
            //HandyControl.Controls.Growl.SuccessGlobal("正在连接数据库...");
            Framez.Source = new Uri("Pagey/Page1.xaml", UriKind.Relative);
            //HandyControl.Controls.Growl.SuccessGlobal("1");
            //HandyControl.Controls.Growl.Success("a");
        }

        private void Page2Button_Click(object sender, RoutedEventArgs e)
        {

            Framez.Source = new Uri("Pagey/Page2.xaml", UriKind.Relative);
        }

        private void Page3Button_Click(object sender, RoutedEventArgs e)
        {
            Framez.Source = new Uri("Pagey/Page4.xaml", UriKind.Relative);
        }
        private void Page4Button_Click(object sender, RoutedEventArgs e)
        {
            Framez.Source = new Uri("Pagey/Page3.xaml", UriKind.Relative);
        }
        private void Page5Button_Click(object sender, RoutedEventArgs e)
        {
            Framez.Source = new Uri("Pagey/Page5.xaml", UriKind.Relative);
        }

        public void tap()
        {
            ILog log = LogManager.GetLogger("Info");
            if (jiance()|| IsApplicationInstalled("TAP-Windows"))
            {
                Console.WriteLine("TAP-Windows已安装");
                log.Info("TAP-Windows已安装");
            }
            else
            {
                Console.WriteLine("TAP-Windows未安装");
                log.Info("TAP-Windows未安装");
                MessageBox.Show("TAP-Windows未安装，程序将会帮您启动安装程序，请在将来弹出的对话框中安装TAP-Windows,请勿更改默认安装目录，并重启本软件", "消息");
                Process.Start(AppDomain.CurrentDomain.BaseDirectory + "\\TAP-Windows\\9.21.2.exe");
                string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;
                Console.WriteLine("当前目录：" + currentDirectory);
                log.Info("当前目录：" + currentDirectory);
                Environment.Exit(0);
            }



        }
        static bool IsApplicationInstalled(string applicationName)
        {
            // 检查注册表中的应用程序列表
            using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"))
            {
                foreach (string subKeyName in key.GetSubKeyNames())
                {
                    using (var subKey = key.OpenSubKey(subKeyName))
                    {
                        string? displayName = subKey.GetValue("DisplayName") as string;
                        if (displayName != null && displayName.Contains(applicationName))
                        {
                            Console.WriteLine("true");
                            return true;
                            
                        }
                    }
                }
            }
            Console.WriteLine("false");
            return false;
        }


        //检测目录中是否存在TAP-Windows
        static bool jiance() {
            string directoryPath = "C:\\Program Files\\TAP-Windows\\bin";  //目录路径
            string fileName = "tapinstall.exe";   //文件名
            bool fileExists = IsFileExists(directoryPath, fileName);
            if (fileExists)
            {
                return true;
            }
            else
            {
                return false;
                
            }


        }

        //扫描目录内文件
        public static bool IsFileExists(string directoryPath, string fileName)
        {
            string filePath = System.IO.Path.Combine(directoryPath, fileName);
            return File.Exists(filePath);
        }


        //关闭按钮
        private void Buttonguanbi_Click(object sender, RoutedEventArgs e)
        {
            //仅关闭本窗口
            //Close();
            Page2.guanbibi();
            //彻底关闭
            Environment.Exit(0);
        }
        //窗口移动
        private void WinMove_main(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
        }
        //最小化窗口
        private void Buttonzuixiaohua_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Buttonset_Click(object sender, RoutedEventArgs e)
        {
            HandyControl.Controls.Growl.SuccessGlobal("设置暂时不可用，请等待后续更新");
        }
    }
}
