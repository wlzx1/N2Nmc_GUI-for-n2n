﻿using HandyControl.Controls;
using Org.BouncyCastle.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using n2nmc.View;
using log4net;


namespace N2Nmc.View
{
    /// <summary>
    /// room.xaml 的交互逻辑
    /// </summary>
    public partial class room : System.Windows.Window
    {
        public room()
        {
            InitializeComponent();
        }

        private void Buttonguanbi_Click(object sender, RoutedEventArgs e)
        {
            // 关闭当前窗口
            n2nmc.View.Pagey.Page2.guanbibi();
            Close();
        }

        //窗口移动
        private void Winmove_room(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
        }
        //最小化窗口
        private void Buttonzuixiaohua_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        public class DataItem
        {
            public string? Community { get; set; }
            public string? Ip4Address { get; set; }
            public string? StuIda { get; set; }
        }
        public string json;
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string url = "http://"+MainView.severapi+"/edges?"+MainView.jiedian;
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    json = await response.Content.ReadAsStringAsync();

                    // 在这里处理返回的 JSON 数据
                    Console.WriteLine(json);
                    //HandyControl.Controls.Growl.SuccessGlobal(json);
                    ILog log = log4net.LogManager.GetLogger(typeof(room));
                    log.Info(json);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("发生异常: " + ex.Message);
                    ILog log = log4net.LogManager.GetLogger(typeof(room));
                    log.Error(ex.Message);
                }
            }

            JArray jsonArray = JArray.Parse(json);

            List<DataItem> dataItems = new List<DataItem>();
            int StuId = 0;
            foreach (JObject jsonObject in jsonArray)
            {
                StuId += 1;
                string? community = (string?)jsonObject["desc"];
                string? ip4addr = (string?)jsonObject["ip4addr"];

                dataItems.Add(new DataItem { StuIda = StuId.ToString(), Community = community, Ip4Address = ip4addr  });
            }

            DataGridroom.ItemsSource = dataItems;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            string url = "http://" + MainView.severapi + "/edges?" + MainView.jiedian;
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();

                    json = await response.Content.ReadAsStringAsync();

                    // 在这里处理返回的 JSON 数据
                    Console.WriteLine(json);
                    //HandyControl.Controls.Growl.SuccessGlobal(json);
                    ILog log = log4net.LogManager.GetLogger(typeof(room));
                    log.Info(json);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("发生异常: " + ex.Message);
                    ILog log = log4net.LogManager.GetLogger(typeof(room));
                    log.Error(ex.Message);
                }
            }

            JArray jsonArray = JArray.Parse(json);

            List<DataItem> dataItems = new List<DataItem>();
            int StuId = 0;
            foreach (JObject jsonObject in jsonArray)
            {
                StuId += 1;
                string? community = (string?)jsonObject["desc"];
                string? ip4addr = (string?)jsonObject["ip4addr"];

                dataItems.Add(new DataItem { StuIda = StuId.ToString(), Community = community, Ip4Address = ip4addr });
            }

            DataGridroom.ItemsSource = dataItems;
        }
    }

}

